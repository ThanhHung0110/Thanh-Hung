﻿namespace QuanLyVatTu2023
{
    internal class MySqlConnection
    {
        private string constr;

        public MySqlConnection(string constr)
        {
            this.constr = constr;
        }
    }
}