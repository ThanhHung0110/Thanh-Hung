﻿namespace QuanLyVatTu2023
{
    partial class FormChuongTrinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.chứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.traCứuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vậtTưĐiệnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vậtTưCơKhíToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vậtTưKhoKýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vậtTưTủKínhVPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.mySqlCommand1 = new MySql.Data.MySqlClient.MySqlCommand();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chứcNăngToolStripMenuItem,
            this.quảnLýToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 36);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1540, 43);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // chứcNăngToolStripMenuItem
            // 
            this.chứcNăngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.traCứuToolStripMenuItem});
            this.chứcNăngToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chứcNăngToolStripMenuItem.Name = "chứcNăngToolStripMenuItem";
            this.chứcNăngToolStripMenuItem.Size = new System.Drawing.Size(157, 37);
            this.chứcNăngToolStripMenuItem.Text = "Chức Năng";
            // 
            // traCứuToolStripMenuItem
            // 
            this.traCứuToolStripMenuItem.Name = "traCứuToolStripMenuItem";
            this.traCứuToolStripMenuItem.Size = new System.Drawing.Size(270, 42);
            this.traCứuToolStripMenuItem.Text = "Tra Cứu";
            this.traCứuToolStripMenuItem.Click += new System.EventHandler(this.traCứuToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vậtTưĐiệnToolStripMenuItem,
            this.vậtTưCơKhíToolStripMenuItem,
            this.vậtTưKhoKýToolStripMenuItem,
            this.vậtTưTủKínhVPToolStripMenuItem});
            this.quảnLýToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(128, 37);
            this.quảnLýToolStripMenuItem.Text = "Quản Lý";
            // 
            // vậtTưĐiệnToolStripMenuItem
            // 
            this.vậtTưĐiệnToolStripMenuItem.Name = "vậtTưĐiệnToolStripMenuItem";
            this.vậtTưĐiệnToolStripMenuItem.Size = new System.Drawing.Size(402, 42);
            this.vậtTưĐiệnToolStripMenuItem.Text = "Vật Tư Điện";
            this.vậtTưĐiệnToolStripMenuItem.Click += new System.EventHandler(this.vậtTưĐiệnToolStripMenuItem_Click);
            // 
            // vậtTưCơKhíToolStripMenuItem
            // 
            this.vậtTưCơKhíToolStripMenuItem.Name = "vậtTưCơKhíToolStripMenuItem";
            this.vậtTưCơKhíToolStripMenuItem.Size = new System.Drawing.Size(402, 42);
            this.vậtTưCơKhíToolStripMenuItem.Text = "Vật Tư Cơ Khí";
            this.vậtTưCơKhíToolStripMenuItem.Click += new System.EventHandler(this.vậtTưCơKhíToolStripMenuItem_Click);
            // 
            // vậtTưKhoKýToolStripMenuItem
            // 
            this.vậtTưKhoKýToolStripMenuItem.Name = "vậtTưKhoKýToolStripMenuItem";
            this.vậtTưKhoKýToolStripMenuItem.Size = new System.Drawing.Size(402, 42);
            this.vậtTưKhoKýToolStripMenuItem.Text = "Vật Tư Kho Kỹ Thuật VP";
            this.vậtTưKhoKýToolStripMenuItem.Click += new System.EventHandler(this.vậtTưKhoKýToolStripMenuItem_Click);
            // 
            // vậtTưTủKínhVPToolStripMenuItem
            // 
            this.vậtTưTủKínhVPToolStripMenuItem.Name = "vậtTưTủKínhVPToolStripMenuItem";
            this.vậtTưTủKínhVPToolStripMenuItem.Size = new System.Drawing.Size(402, 42);
            this.vậtTưTủKínhVPToolStripMenuItem.Text = "Vật Tư Tủ Kính VP";
            this.vậtTưTủKínhVPToolStripMenuItem.Click += new System.EventHandler(this.vậtTưTủKínhVPToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LimeGreen;
            this.label1.Location = new System.Drawing.Point(56, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1385, 275);
            this.label1.TabIndex = 17;
            this.label1.Text = "Chào Mừng Bạn Đến Với Kho Vật Tư \r\n       Công Ty FWD Automation\r\n ";
            // 
            // mySqlCommand1
            // 
            this.mySqlCommand1.CacheAge = 0;
            this.mySqlCommand1.Connection = null;
            this.mySqlCommand1.EnableCaching = false;
            this.mySqlCommand1.Transaction = null;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Chartreuse;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(823, 846);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(205, 68);
            this.button2.TabIndex = 19;
            this.button2.Text = "shut down";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.shutdownButton_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Chartreuse;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(551, 845);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(185, 69);
            this.button1.TabIndex = 18;
            this.button1.Text = "Đăng xuất";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btndangxuat);
            // 
            // menuStrip2
            // 
            this.menuStrip2.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1540, 36);
            this.menuStrip2.TabIndex = 20;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // FormChuongTrinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1540, 1050);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormChuongTrinh";
            this.Text = "FormChuongTrinh";
            this.Load += new System.EventHandler(this.FormChuongTrinh_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem chứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vậtTưĐiệnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vậtTưCơKhíToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vậtTưKhoKýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem traCứuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vậtTưTủKínhVPToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private MySql.Data.MySqlClient.MySqlCommand mySqlCommand1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip2;
    }
}