﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyVatTu2023
{
    public partial class FormChuongTrinh : Form
    {
        public FormChuongTrinh()
        {
            InitializeComponent();
        }

        private void vậtTưKhoKýToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVatTuKhoKyThuatVP f = new FormVatTuKhoKyThuatVP();
            f.Show();

            this.Hide();
        }

        private void traCứuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTraCuu f = new FormTraCuu();
            f.Show();
            this.Hide();
        }

        private void vậtTưĐiệnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVatTuDien f = new FormVatTuDien();
            f.Show();

            this.Hide();
        }

        private void vậtTưCơKhíToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVatTuCoKhi f = new FormVatTuCoKhi();
            f.Show();
            this.Hide();

        }

        private void vậtTưTủKínhVPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVatTuTuKinhVP f = new FormVatTuTuKinhVP();
            f.Show();

            this.Hide();
        }

        private void btndangxuat(object sender, EventArgs e)
        {
            FormDangNhap f = new FormDangNhap();
            f.Show();
            this.Hide();
        }

        private void FormChuongTrinh_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            // Tắt thanh tiêu đề
            this.FormBorderStyle = FormBorderStyle.None;
        }

        private void shutdownButton_Click(object sender, EventArgs e)
        {
            // Tắt máy tính
            Process.Start("shutdown", "/s /t 0");
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
           
        }
    }
}
