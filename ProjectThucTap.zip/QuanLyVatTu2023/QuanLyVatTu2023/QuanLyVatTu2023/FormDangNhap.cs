﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyVatTu2023
{
    public partial class FormDangNhap : Form
    {
        string tentaikhoan = "admin";
        string matkhau = "admin";
      
        public FormDangNhap()
        {
            InitializeComponent();
        }

        bool kiemTraDangNhap(string tentaikhoan, string matkhau)
        {
            if(tentaikhoan == this.tentaikhoan && matkhau == this.matkhau) 
            {
                return true;
            }
            return false;
        }

        private void FormDangNhap_FormClosing(object sender, FormClosingEventArgs e)
        {
            /*if (MessageBox.Show("Bạn Muốn Thoát Chương Trình", "Cảnh Báo", MessageBoxButtons.YesNo) != DialogResult.Yes)
                e.Cancel = true;*/
            Environment.Exit(0);
        }

        private void buttonThoat(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void buttonDangNhap(object sender, EventArgs e)
        {
            if (kiemTraDangNhap(txttaikhoan.Text, txtmatkhau.Text))
            {
                FormTraCuu f = new FormTraCuu();
                f.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu", "Mời bạn nhập lại");
                txttaikhoan.Focus();
            }
        }

        private void FormDangNhap_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            // Tắt thanh tiêu đề
            this.FormBorderStyle = FormBorderStyle.None;
        }

        private void btnBanPhim(object sender, EventArgs e)
        {
            try
            {
                // Đường dẫn tới chương trình bàn phím ảo
                string virtualKeyboardPath = "G:\\My Drive\\THUCTAP_QUAN_LY_VAT_TU\\PHIM_AO\\FreeVK\\FreeVK.exe";

                // Khởi chạy chương trình bàn phím ảo
                Process.Start(virtualKeyboardPath);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnbanphim(object sender, EventArgs e)
        {
            try
            {
                // Đường dẫn tới chương trình bàn phím ảo
                string virtualKeyboardPath = "G:\\My Drive\\THUCTAP_QUAN_LY_VAT_TU\\PHIM_AO\\FreeVK\\FreeVK.exe";

                // Khởi chạy chương trình bàn phím ảo
                Process.Start(virtualKeyboardPath);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
