﻿namespace QuanLyVatTu2023
{
    internal class MysqlDataAdapter
    {
    }
}