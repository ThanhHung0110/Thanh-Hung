﻿using System;
using MySql.Data;
using MySql;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace QuanLyVatTu2023
{
    public partial class FormVatTuTuKinhVP : Form
    {
        public FormVatTuTuKinhVP()
        {
            InitializeComponent();
        }

        private void buttonLui_Click(object sender, EventArgs e)
        {
            FormChuongTrinh f = new FormChuongTrinh();
            f.Show();
            this.Hide();
        }



        string str = "server=127.0.0.1; Database = quan_ly_vat_tu; Uid= root; Pwd = ; CharSet=utf8";

        private void loadData()
        {
            /*using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("select * from tb_vattutukinhvp", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

            }*/

            /* using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
             {
                 con.Open();
                 MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM tb_vattutukinhvp", con);

                 DataTable dt = new DataTable();
                 da.Fill(dt);
                 dataGridView1.DataSource = dt;

                 // Đặt thuộc tính ReadOnly của dataGridView1 thành true
                 dataGridView1.ReadOnly = true;

                 // Định dạng kích thước các cột
                 dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
             }*/

            /*using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM tb_vattutukinhvp", con);

                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Đặt thuộc tính ReadOnly của dataGridView1 thành true
                dataGridView1.ReadOnly = true;

                // Đổi tên và thứ tự các cột
                dataGridView1.Columns["maVatTu"].HeaderText = "Mã vật tư";
                dataGridView1.Columns["tenVatTu"].HeaderText = "Tên vật tư";
                dataGridView1.Columns["soLuong"].HeaderText = "Số lượng";
                dataGridView1.Columns["hang"].HeaderText = "Hãng";
                dataGridView1.Columns["donVi"].HeaderText = "Đơn vị";
                dataGridView1.Columns["note"].HeaderText = "Note";
                dataGridView1.Columns["dateTime"].HeaderText = "Ngày";
                dataGridView1.Columns["viTri"].HeaderText = "Vị trí";

                // Căn giữa tiêu đề
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }

                // Định dạng kích thước các cột
                dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }*/

            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM tb_vattutukinhvp", con);

                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Đặt thuộc tính ReadOnly của dataGridView1 thành true
                dataGridView1.ReadOnly = true;

                // Đổi tên và thứ tự các cột
                dataGridView1.Columns["maVatTu"].HeaderText = "Model";
                dataGridView1.Columns["tenVatTu"].HeaderText = "Tên hàng";
                dataGridView1.Columns["soLuong"].HeaderText = "SL";
                dataGridView1.Columns["hang"].HeaderText = "Hãng";
                dataGridView1.Columns["donVi"].HeaderText = "ĐVT";
                dataGridView1.Columns["note"].HeaderText = "Ghi chú";
                dataGridView1.Columns["dateTime"].HeaderText = "Ngày";
                dataGridView1.Columns["viTri"].HeaderText = "Vị trí";

                // Căn giữa tiêu đề
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }

                // Đặt kích thước cho từng cột
                dataGridView1.Columns["id"].Width = Convert.ToInt32(0.0001 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["maVatTu"].Width = Convert.ToInt32(3.7 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["tenVatTu"].Width = Convert.ToInt32(3.7 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["soLuong"].Width = Convert.ToInt32(1.3 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["hang"].Width = Convert.ToInt32(1.5 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["donVi"].Width = Convert.ToInt32(1.8 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["note"].Width = Convert.ToInt32(3 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["dateTime"].Width = Convert.ToInt32(2.2 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["viTri"].Width = Convert.ToInt32(2.4 * dataGridView1.Width / 20); // 2cm

                // Định dạng kích thước các cột
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            /*string query = string.Format("INSERT INTO tb_vattutukinhvp VALUES (NULL, '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')", txtMa.Text, txtTen.Text, txtSL.Text, txtHang.Text, txtDvt.Text, txtNote.Text, dateTime.Value.ToString("yyyy-MM-dd"), txtViTri.Text);
            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand(query, con);
                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    MessageBox.Show("Bạn Đã Thêm Thành Công");
                    loadData();
                    txtMa.Clear();
                    txtTen.Clear();
                    txtSL.Clear();
                    txtHang.Clear();
                    txtDvt.Clear();
                    txtNote.Clear();
                    txtViTri.Clear();
                }

                // Chuyển dữ liệu từ bảng tb_vattutukinhvp vào tb_tonghop
                string insertQueryVatTuTuKinhVP = "INSERT INTO tb_tonghop2 (id, maVatTu, tenVatTu, soLuong, hang, donVi, note, dateTime, viTri) SELECT id, maVatTu, tenVatTu, soLuong, hang, donVi, note, dateTime, viTri FROM tb_vattutukinhvp";
                MySqlCommand insertCmdVatTuTuKinhVP = new MySqlCommand(insertQueryVatTuTuKinhVP, con);
                insertCmdVatTuTuKinhVP.ExecuteNonQuery();

            }*/

            string querySelect = string.Format("SELECT COUNT(*) FROM tb_vattutukinhvp WHERE maVatTu = '{0}'", txtMa.Text);
            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlCommand cmdSelect = new MySqlCommand(querySelect, con);
                int count = Convert.ToInt32(cmdSelect.ExecuteScalar());
                if (count > 0)
                {
                    MessageBox.Show("Sản phẩm đã tồn tại. Không thể thêm.");
                }
                else
                {
                    string queryInsert = string.Format("INSERT INTO tb_vattutukinhvp VALUES (NULL, '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}')", txtMa.Text, txtTen.Text, txtSL.Text, txtHang.Text, txtDvt.Text, txtNote.Text, dateTime.Value.ToString("yyyy-MM-dd"), txtViTri.Text);
                    MySqlCommand cmdInsert = new MySqlCommand(queryInsert, con);
                    int result = cmdInsert.ExecuteNonQuery();
                    if (result == 1)
                    {
                        MessageBox.Show("Bạn đã thêm thành công");
                        loadData();
                        txtMa.Clear();
                        txtTen.Clear();
                        txtSL.Clear();
                        txtHang.Clear();
                        txtDvt.Clear();
                        txtNote.Clear();
                    }
                }

                // Đưa dữ liệu vào table tong hop
                /* string insertQueryVatTuTuKinhVP = "INSERT INTO tb_tonghop2 (id, maVatTu, tenVatTu, soLuong, hang, donVi, note, dateTime, viTri) SELECT id, maVatTu, tenVatTu, soLuong, hang, donVi, note, dateTime, viTri FROM tb_vattutukinhvp";
                 MySqlCommand insertCmdVatTuTuKinhVP = new MySqlCommand(insertQueryVatTuTuKinhVP, con);
                 insertCmdVatTuTuKinhVP.ExecuteNonQuery();*/

                string insertQueryVatTuTuKinhVP = "INSERT INTO tb_tonghop2 (id, maVatTu, tenVatTu, soLuong, hang, donVi, note, dateTime, viTri) SELECT id, maVatTu, tenVatTu, soLuong, hang, donVi, note, dateTime, viTri FROM tb_vattutukinhvp WHERE maVatTu NOT IN (SELECT maVatTu FROM tb_tonghop2)";
                MySqlCommand insertCmdVatTuTuKinhVP = new MySqlCommand(insertQueryVatTuTuKinhVP, con);
                insertCmdVatTuTuKinhVP.ExecuteNonQuery();
            }
        }

        private void FormVatTuTuKinhVP_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            loadData();
            // Tắt thanh tiêu đề
            this.FormBorderStyle = FormBorderStyle.None;
        }

        private void btnMuon_Click(object sender, EventArgs e)
        {
            /*
              int soLuongMuon = int.Parse(txtSL.Text);
              string querySelect = string.Format("SELECT soLuong FROM tb_vattutukinhvp WHERE id = {0}", id);

              using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
              {
                  con.Open();

                  // Thực hiện câu lệnh SELECT để lấy số lượng hiện có
                  MySqlCommand cmdSelect = new MySqlCommand(querySelect, con);
                  int soLuongHienCo = (int)cmdSelect.ExecuteScalar();

                  // Kiểm tra số lượng mượn lớn hơn số lượng hiện có
                  if (soLuongMuon > soLuongHienCo)
                  {
                      MessageBox.Show("Số lượng mượn lớn hơn số lượng hiện có. Không thể thực hiện mượn!");
                      return;
                  }

                  // Tiến hành trừ vào số lượng
                  string queryUpdate = string.Format("UPDATE tb_vattutukinhvp SET soLuong = soLuong - {0} WHERE id = {1}", soLuongMuon, id);
                  MySqlCommand cmdUpdate = new MySqlCommand(queryUpdate, con);
                  int result = cmdUpdate.ExecuteNonQuery();

                  if (result == 1)
                  {
                      MessageBox.Show("Bạn Đã Mượn Thành Công");
                      loadData();
                      txtMa.Clear();
                      txtTen.Clear();
                      txtSL.Clear();
                      txtHang.Clear();
                      txtDvt.Clear();
                      txtNote.Clear();
                      txtViTri.Clear();
                  }
              }*/

            int soLuongMuon = int.Parse(txtSL.Text);
            string querySelect = string.Format("SELECT soLuong FROM tb_vattutukinhvp WHERE id = {0}", id);

            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                // Thực hiện câu lệnh SELECT để lấy số lượng hiện có
                MySqlCommand cmdSelect = new MySqlCommand(querySelect, con);
                int soLuongHienCo = Convert.ToInt32(cmdSelect.ExecuteScalar());

                // Kiểm tra số lượng mượn lớn hơn số lượng hiện có
                if (soLuongMuon > soLuongHienCo)
                {
                    MessageBox.Show("Số lượng mượn lớn hơn số lượng hiện có. Không thể thực hiện mượn!");
                    return;
                }

                // Tiến hành trừ vào số lượng
                string queryUpdateVattucokhi = string.Format("UPDATE tb_vattutukinhvp SET soLuong = soLuong - {0} WHERE id = {1}", soLuongMuon, id);
                string queryUpdateTonghop2 = string.Format("UPDATE tb_tonghop2 SET soLuong = soLuong - {0} WHERE id = {1}", soLuongMuon, id);

                MySqlCommand cmdUpdateVattucokhi = new MySqlCommand(queryUpdateVattucokhi, con);
                MySqlCommand cmdUpdateTonghop2 = new MySqlCommand(queryUpdateTonghop2, con);

                int resultVattucokhi = cmdUpdateVattucokhi.ExecuteNonQuery();
                int resultTonghop2 = cmdUpdateTonghop2.ExecuteNonQuery();

                if (resultVattucokhi > 0 && resultTonghop2 > 0)
                {
                    MessageBox.Show("Bạn Đã Mượn Thành Công");
                    loadData();
                    txtMa.Clear();
                    txtTen.Clear();
                    txtSL.Clear();
                    txtHang.Clear();
                    txtDvt.Clear();
                    txtNote.Clear();
                    txtViTri.Clear();
                }
            }
        }

        public string id { get; set; }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            /*string query = string.Format("UPDATE tb_vattutukinhvp SET maVatTu = '{0}', tenVatTu ='{1}', soLuong = '{2}', hang = '{3}', donVi = '{4}', note = '{5}', dateTime = '{6}', ViTri ='{7}' WHERE id = {8}", txtMa.Text, txtTen.Text, txtSL.Text, txtHang.Text, txtDvt.Text, txtNote.Text, dateTime.Value.ToString("yyyy-MM-dd"), txtViTri.Text, id);
            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand(query, con);
                int result = cmd.ExecuteNonQuery();
                if (result == 1)
                {
                    MessageBox.Show("Bạn Đã Update Thành Công");
                    loadData();
                    txtMa.Clear();
                    txtTen.Clear();
                    txtSL.Clear();
                    txtHang.Clear();
                    txtDvt.Clear();
                    txtNote.Clear();
                    txtViTri.Clear();
                }

            }*/
            string queryVattutukinhvp = string.Format("UPDATE tb_vattutukinhvp SET maVatTu = '{0}', tenVatTu = '{1}', hang = '{3}', donVi = '{4}', note = '{5}', dateTime = '{6}', ViTri = '{7}' WHERE id = {8}", txtMa.Text, txtTen.Text, txtSL.Text, txtHang.Text, txtDvt.Text, txtNote.Text, dateTime.Value.ToString("yyyy-MM-dd"), txtViTri.Text, id);
            string queryTonghop2 = string.Format("UPDATE tb_tonghop2 SET maVatTu = '{0}', tenVatTu = '{1}', hang = '{3}', donVi = '{4}', note = '{5}', dateTime = '{6}', ViTri = '{7}' WHERE id = {8}", txtMa.Text, txtTen.Text, txtSL.Text, txtHang.Text, txtDvt.Text, txtNote.Text, dateTime.Value.ToString("yyyy-MM-dd"), txtViTri.Text, id);

            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                MySqlCommand cmdVattutukinhvp = new MySqlCommand(queryVattutukinhvp, con);
                MySqlCommand cmdTonghop2 = new MySqlCommand(queryTonghop2, con);

                int resultVattutukinhvp = cmdVattutukinhvp.ExecuteNonQuery();
                int resultTonghop2 = cmdTonghop2.ExecuteNonQuery();

                if (resultVattutukinhvp > 0 && resultTonghop2 > 0)
                {
                    MessageBox.Show("Bạn Đã Update Thành Công");
                    loadData();
                    txtMa.Clear();
                    txtTen.Clear();
                    txtSL.Clear();
                    txtHang.Clear();
                    txtDvt.Clear();
                    txtNote.Clear();
                    txtViTri.Clear();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            /*string query = string.Format("DELETE FROM tb_vattutukinhvp WHERE id = {0}", id);
            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlCommand command = new MySqlCommand(query, con);
                  
                int result = command.ExecuteNonQuery();
                if (result == 1)
                {
                    MessageBox.Show("Xoá Thành Công");
                    loadData();

                }

            }*/
            string query = string.Format("DELETE tb_vattutukinhvp, tb_tonghop2 FROM tb_vattutukinhvp INNER JOIN tb_tonghop2 ON tb_vattutukinhvp.id = tb_tonghop2.id WHERE tb_vattutukinhvp.id = {0}", id);

            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlCommand command = new MySqlCommand(query, con);

                int result = command.ExecuteNonQuery();
                if (result > 0)
                {
                    MessageBox.Show("Xoá Thành Công");
                    loadData();
                }
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                //check lại mấy điểm này xem nó trả về số mấy nha
                id = row.Cells[0].Value.ToString();
                txtMa.Text = row.Cells[1].Value.ToString();
                txtTen.Text = row.Cells[2].Value.ToString();
                txtSL.Text = row.Cells[3].Value.ToString();
                txtHang.Text = row.Cells[4].Value.ToString();
                txtDvt.Text = row.Cells[5].Value.ToString();
                txtNote.Text = row.Cells[6].Value.ToString();
                dateTime.Value = Convert.ToDateTime(row.Cells[7].Value);
                txtViTri.Text = row.Cells[8].Value.ToString();

            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                //check lại mấy điểm này xem nó trả về số mấy nha
                id = row.Cells[0].Value.ToString();
            }
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                //check lại mấy điểm này xem nó trả về số mấy nha
                id = row.Cells[0].Value.ToString();
                txtMa.Text = row.Cells[1].Value.ToString();
                txtTen.Text = row.Cells[2].Value.ToString();
                txtSL.Text = row.Cells[3].Value.ToString();
                txtHang.Text = row.Cells[4].Value.ToString();
                txtDvt.Text = row.Cells[5].Value.ToString();
                txtNote.Text = row.Cells[6].Value.ToString();
                dateTime.Value = Convert.ToDateTime(row.Cells[7].Value);
                txtViTri.Text = row.Cells[8].Value.ToString();

            }
        }


        private void btnTra_Click(object sender, EventArgs e)
        {
            /* int soLuongMuon = int.Parse(txtSL.Text);
             string query = string.Format("UPDATE tb_vattutukinhvp SET soLuong = soLuong + {0} WHERE id = {1}", soLuongMuon, id);

             using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
             {
                 con.Open();
                 MySqlCommand cmd = new MySqlCommand(query, con);
                 int result = cmd.ExecuteNonQuery();
                 if (result == 1)
                 {
                     MessageBox.Show("Bạn Đã Trả Hàng Thành Công");
                     loadData();
                     txtMa.Clear();
                     txtTen.Clear();
                     txtSL.Clear();
                     txtHang.Clear();
                     txtDvt.Clear();
                     txtNote.Clear();
                     txtViTri.Clear();
                 }

             }*/

            int soLuongTra = int.Parse(txtSL.Text);

            string updateQuery1 = string.Format("UPDATE tb_vattutukinhvp SET soLuong = soLuong + {0} WHERE id = {1}", soLuongTra, id);
            string updateQuery2 = string.Format("UPDATE tb_tonghop2 SET soLuong = soLuong + {0} WHERE id = {1}", soLuongTra, id);

            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                MySqlCommand cmd1 = new MySqlCommand(updateQuery1, con);
                int result1 = cmd1.ExecuteNonQuery();

                MySqlCommand cmd2 = new MySqlCommand(updateQuery2, con);
                int result2 = cmd2.ExecuteNonQuery();

                if (result1 == 1 && result2 == 1)
                {
                    MessageBox.Show("Bạn Đã Trả Hàng Thành Công");
                    loadData();
                    txtMa.Clear();
                    txtTen.Clear();
                    txtSL.Clear();
                    txtHang.Clear();
                    txtDvt.Clear();
                    txtNote.Clear();
                    txtViTri.Clear();
                }
            }
        }


        public void loadGridByKeyword()
        {
            /*using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("select * from tb_vattutukinhvp where tenVatTu like '%" + txtTenVatTu.Text + "%'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }*/

            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                string query = "SELECT * FROM tb_vattutukinhvp WHERE tenVatTu LIKE @tenVatTu AND maVatTu LIKE @maVatTu";
                MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                da.SelectCommand.Parameters.AddWithValue("@tenVatTu", "%" + txtTenVatTu.Text + "%");
                da.SelectCommand.Parameters.AddWithValue("@maVatTu", "%" + txtMaVatTu.Text + "%");
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
        private void btnSeach_Click(object sender, EventArgs e)
        {
            loadGridByKeyword();
        }

        private void btnHienThi_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void btnExcel(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ToExcel(dataGridView1, saveFileDialog1.FileName);
            }
        }
        private void ToExcel(DataGridView dataGridView1, string fileName)
        {
            Microsoft.Office.Interop.Excel.Application excel;
            Microsoft.Office.Interop.Excel.Workbook workbook;
            Microsoft.Office.Interop.Excel.Worksheet worksheet;

            try
            {
                excel = new Microsoft.Office.Interop.Excel.Application();
                excel.Visible = false;
                excel.DisplayAlerts = false;

                workbook = excel.Workbooks.Add(Type.Missing);

                worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets["Sheet1"];
                worksheet.Name = "VẬT TƯ TỦ KÍNH VP";

                // export header
                for (int i = 0; i < dataGridView1.ColumnCount; i++)
                {
                    worksheet.Cells[1, i + 1] = dataGridView1.Columns[i].HeaderText;
                }

                // export content
                for (int i = 0; i < dataGridView1.RowCount; i++)
                {
                    for (int j = 0; j < dataGridView1.ColumnCount; j++)
                    {
                        worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }

                // save workbook
                workbook.SaveAs(fileName);
                workbook.Close();
                excel.Quit();
                MessageBox.Show("Export successful.!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                workbook = null;
                worksheet = null;
            }
        }

        private void FormVatTuTuKinhVP_FormClosed(object sender, FormClosedEventArgs e)
        {
            FormDangNhap f = new FormDangNhap();
            f.Show();
            this.Hide();
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void txtTenVatTu_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtMa_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void dateTime_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtViTri_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void btnbanphim(object sender, EventArgs e)
        {
            try
            {
                // Đường dẫn tới chương trình bàn phím ảo
                string virtualKeyboardPath = "G:\\My Drive\\THUCTAP_QUAN_LY_VAT_TU\\PHIM_AO\\FreeVK\\FreeVK.exe";

                // Khởi chạy chương trình bàn phím ảo
                Process.Start(virtualKeyboardPath);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}
