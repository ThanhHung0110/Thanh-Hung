﻿using MySql.Data.MySqlClient;
using MySql.Data;
using MySql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
//using System.Data.SqlClient;

namespace QuanLyVatTu2023
{
    public partial class FormTraCuu : Form
    {
        private DataSet dataSet;

        bool isThoat = true;
        public FormTraCuu()
        {
            InitializeComponent();
        }

        private void FormTraCuu_FormClosing(object sender, FormClosingEventArgs e)
        {
            /*if (isThoat)
            {
                if (MessageBox.Show("Bạn Chắc Chắn Muốn Thoát Chương Trình", "Cảnh Báo", MessageBoxButtons.YesNo) != DialogResult.Yes)
                    e.Cancel = true;
                this.Close();
            }*/
            
            FormDangNhap f = new FormDangNhap();
            f.Show();
            this.Hide();
        }

        private void btnLui(object sender, EventArgs e)
        {
            /* isThoat = false;
             this.Close();
            // this.Hide();
             FormChuongTrinh f = new FormChuongTrinh();
             f.Show();*/

            FormChuongTrinh f = new FormChuongTrinh();
            f.Show();
            this.Hide();

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        string str = "server=127.0.0.1; Database = quan_ly_vat_tu; Uid= root; Pwd = ; CharSet=utf8";

        private void loadData()
        {
            /*using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                // Tạo bảng tb_tonghop nếu chưa tồn tại
                string createTableQuery = "CREATE TABLE IF NOT EXISTS tb_tonghop2 (id INT, maVatTu VARCHAR(100), tenVatTu VARCHAR(100), soLuong INT, hang VARCHAR(100), donVi VARCHAR(100), note VARCHAR(100), dateTime DATETIME, viTri VARCHAR(100))";
                MySqlCommand createTableCmd = new MySqlCommand(createTableQuery, con);
                createTableCmd.ExecuteNonQuery();


                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM tb_tonghop2", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }*/

            /*using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                // Tạo bảng tb_tonghop nếu chưa tồn tại
                string createTableQuery = "CREATE TABLE IF NOT EXISTS tb_tonghop2 (id INT, maVatTu VARCHAR(500), tenVatTu VARCHAR(100), soLuong INT, hang VARCHAR(100), donVi VARCHAR(100), note VARCHAR(100), dateTime DATETIME, viTri VARCHAR(100))";
                MySqlCommand createTableCmd = new MySqlCommand(createTableQuery, con);
                createTableCmd.ExecuteNonQuery();

                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM tb_tonghop2", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Định dạng kích thước các cột
                dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }*/

            /*using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                // Tạo bảng tb_tonghop nếu chưa tồn tại
                string createTableQuery = "CREATE TABLE IF NOT EXISTS tb_tonghop2 (id INT, maVatTu VARCHAR(500), tenVatTu VARCHAR(100), soLuong INT, hang VARCHAR(100), donVi VARCHAR(100), note VARCHAR(100), dateTime DATETIME, viTri VARCHAR(100))";
                MySqlCommand createTableCmd = new MySqlCommand(createTableQuery, con);
                createTableCmd.ExecuteNonQuery();

                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM tb_tonghop2", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Xóa cột "id" khỏi dataGridView1
                dataGridView1.Columns.Remove("id");

                // Định dạng kích thước các cột
                dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }*/

            /*using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                // Tạo bảng tb_tonghop nếu chưa tồn tại
                string createTableQuery = "CREATE TABLE IF NOT EXISTS tb_tonghop2 (id INT, maVatTu VARCHAR(500), tenVatTu VARCHAR(100), soLuong INT, hang VARCHAR(100), donVi VARCHAR(100), note VARCHAR(100), dateTime DATETIME, viTri VARCHAR(100))";
                MySqlCommand createTableCmd = new MySqlCommand(createTableQuery, con);
                createTableCmd.ExecuteNonQuery();

                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM tb_tonghop2", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Xóa cột "id" khỏi dataGridView1
                dataGridView1.Columns.Remove("id");

                // Đặt thuộc tính ReadOnly của dataGridView1 thành true
                dataGridView1.ReadOnly = true;

                // Định dạng kích thước các cột
                dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }*/

            /*using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                // Tạo bảng tb_tonghop nếu chưa tồn tại
                string createTableQuery = "CREATE TABLE IF NOT EXISTS tb_tonghop2 (id INT, maVatTu VARCHAR(500), tenVatTu VARCHAR(100), soLuong INT, hang VARCHAR(100), donVi VARCHAR(100), note VARCHAR(100), dateTime DATETIME, viTri VARCHAR(100))";
                MySqlCommand createTableCmd = new MySqlCommand(createTableQuery, con);
                createTableCmd.ExecuteNonQuery();

                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM tb_tonghop2", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Xóa cột "id" khỏi dataGridView1
                dataGridView1.Columns.Remove("id");

                // Đặt thuộc tính ReadOnly của dataGridView1 thành true
                dataGridView1.ReadOnly = true;

                // Đổi tên và thứ tự các cột
                dataGridView1.Columns["maVatTu"].HeaderText = "Mã vật tư";
                dataGridView1.Columns["tenVatTu"].HeaderText = "Tên vật tư";
                dataGridView1.Columns["soLuong"].HeaderText = "Số lượng";
                dataGridView1.Columns["hang"].HeaderText = "Hãng";
                dataGridView1.Columns["donVi"].HeaderText = "Đơn vị";
                dataGridView1.Columns["note"].HeaderText = "Note";
                dataGridView1.Columns["dateTime"].HeaderText = "Ngày";
                dataGridView1.Columns["viTri"].HeaderText = "Vị trí";

                // Căn giữa tiêu đề
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }

                // Định dạng kích thước các cột
                dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }*/


            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                // Tạo bảng tb_tonghop nếu chưa tồn tại
                string createTableQuery = "CREATE TABLE IF NOT EXISTS tb_tonghop2 (id INT, maVatTu VARCHAR(500), tenVatTu VARCHAR(100), soLuong INT, hang VARCHAR(100), donVi VARCHAR(100), note VARCHAR(100), dateTime DATETIME, viTri VARCHAR(100))";
                MySqlCommand createTableCmd = new MySqlCommand(createTableQuery, con);
                createTableCmd.ExecuteNonQuery();

                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM tb_tonghop2", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Xóa cột "id" khỏi dataGridView1
                dataGridView1.Columns.Remove("id");

                // Đặt thuộc tính ReadOnly của dataGridView1 thành true
                dataGridView1.ReadOnly = true;

                // Đổi tên và thứ tự các cột
                dataGridView1.Columns["maVatTu"].HeaderText = "Model";
                dataGridView1.Columns["tenVatTu"].HeaderText = "Tên hàng";
                dataGridView1.Columns["soLuong"].HeaderText = "SL";
                dataGridView1.Columns["hang"].HeaderText = "Hãng";
                dataGridView1.Columns["donVi"].HeaderText = "ĐVT";
                dataGridView1.Columns["note"].HeaderText = "Note";
                dataGridView1.Columns["dateTime"].HeaderText = "Ngày";
                dataGridView1.Columns["viTri"].HeaderText = "Vị trí";

                // Căn giữa tiêu đề
                foreach (DataGridViewColumn column in dataGridView1.Columns)
                {
                    column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }

                // Đặt kích thước cho từng cột
                dataGridView1.Columns["maVatTu"].Width = Convert.ToInt32(3.7 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["tenVatTu"].Width = Convert.ToInt32(3.7 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["soLuong"].Width = Convert.ToInt32(1.3 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["hang"].Width = Convert.ToInt32(1.5 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["donVi"].Width = Convert.ToInt32(1.8 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["note"].Width = Convert.ToInt32(3 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["dateTime"].Width = Convert.ToInt32(2.2 * dataGridView1.Width / 20); // 3cm
                dataGridView1.Columns["viTri"].Width = Convert.ToInt32(2.4 * dataGridView1.Width / 20); // 2cm


                // Định dạng kích thước các cột
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            }




        }

        private void FormTraCuu_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            loadData();
            // Tắt thanh tiêu đề
            this.FormBorderStyle = FormBorderStyle.None;
        }

        public void loadGridByKeyword()
        {
            /*using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();
                MySqlDataAdapter da = new MySqlDataAdapter("select * from tb_tonghop2 where tenVatTu like '%" + txtTenVatTu.Text + "%'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }*/

            using (MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(str))
            {
                con.Open();

                string query = "SELECT * FROM tb_tonghop2 WHERE tenVatTu LIKE @tenVatTu AND maVatTu LIKE @maVatTu";
                MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                da.SelectCommand.Parameters.AddWithValue("@tenVatTu", "%" + txtTenVatTu.Text + "%");
                da.SelectCommand.Parameters.AddWithValue("@maVatTu", "%" + txtMaVatTu.Text + "%");
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void btnSeach_Click(object sender, EventArgs e)
        {
            loadGridByKeyword();
        }

        private void btnHienThi_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBanPhim(object sender, EventArgs e)
        {
            try
            {
                // Đường dẫn tới chương trình bàn phím ảo
                string virtualKeyboardPath = "G:\\My Drive\\THUCTAP_QUAN_LY_VAT_TU\\PHIM_AO\\FreeVK\\FreeVK.exe";

                // Khởi chạy chương trình bàn phím ảo
                Process.Start(virtualKeyboardPath);
            }
            catch (Exception ex)
            {
                // Xử lý lỗi nếu có
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}
